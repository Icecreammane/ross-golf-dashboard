# MEMORY.md — Long-Term Memory

*Curated knowledge and insights about Ross and our work together.*

---

## Who Ross Is
- **Age:** 30 | **Location:** Nolensville, TN
- **Career:** Product developer, pet food industry
- **Status:** Single
- Dreams of escaping corporate life for Florida — beach volleyball, golf, freedom

## The Big Goals
1. **Financial Freedom** — build income outside the 9-5
2. **Peak Fitness** — structured weightlifting, real results
3. **Fantasy Football Glory** — championship or bust
4. **The Florida Dream** — the ultimate destination

## Working Style
- Wants a co-pilot who pushes him, not just answers questions
- Action-oriented — prefers plans over theory
- Competitive streak (fantasy sports, fitness PRs)

## Key Dates
- **2025-07-22:** Day One. Jarvis came online.

---

*Updated as we learn and grow.*
